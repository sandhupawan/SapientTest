$(document).ready(function(){	
	$('#dispense-money').click(function(){
		var getVal = $('.amount-value').val();
		$('.get-amount-list').html('');
		getAmt(getVal);
	});
	function getAmt(value)
	{
		var dispensed = 0;
		var currencyNotes = [2000,500,200,100,50,20,10,5,2,1]
		for(var i=0;i<currencyNotes.length;i++)
		{
			if(value!=0)
			{
				var quot = Math.floor(value/currencyNotes[i]);
                var remainder = value % currencyNotes[i];
		        value = remainder;
				if(quot!=0)
				{
		        $('.get-amount-list').append('<li> '+ quot +' notes of Rs '+ currencyNotes[i] +' </li>');
				}
		        dispensed=quot+dispensed;
		        $('.dispensed span').text(dispensed);
			}
		}
		console.log($('.get-amount-list li').length);
	}
});